<?php
// URL absoluta do site, usada nas meta tags de compartilhamento (Facebook, WhatsApp, LinkedIn, X).
// Detectada automaticamente; para fixar, preencha URL_SITE em api/config.php.
require_once __DIR__ . '/api/config.php';
// Garante que o banco de dados exista já na primeira visita (sem depender do JavaScript).
// Se algo falhar (ex.: permissão da pasta dados/), a página continua abrindo; veja api/instalar.php.
try { require_once __DIR__ . '/api/db.php'; restore_exception_handler(); db(); } catch (Throwable $e) { error_log('[admoema-midia] banco: ' . $e->getMessage()); }
$url_site = defined('URL_SITE') && URL_SITE !== '' ? rtrim(URL_SITE, '/') . '/' : (function () {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host  = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $dir   = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    return ($https ? 'https' : 'http') . '://' . $host . $dir . '/';
})();
$h = fn($v) => htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
// Versão dos arquivos de estilo/script: muda a cada atualização, para o navegador não usar cache antigo
$v = fn(string $f) => $f . '?v=' . (@filemtime(__DIR__ . '/' . $f) ?: '1');
$titulo_share = 'Ministério de Mídia ADMoema · Servir, Comunicar, Capacitar, Evangelizar';
$descricao_share = 'Proposta de estruturação e expansão do Ministério de Mídia da Assembleia de Deus – Ministério do Belém, Setor 124, Moema. Conheça as nove frentes de trabalho e diga onde você pode contribuir.';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ministério de Mídia ADMoema · Servir, Comunicar, Capacitar, Evangelizar</title>
  <meta name="description" content="Proposta de estruturação e expansão do Ministério de Mídia da Assembleia de Deus – Ministério do Belém, Setor 124, Moema. Conheça as nove frentes de trabalho e diga onde você pode contribuir.">
  <meta name="theme-color" content="#0b1f3a">
  <link rel="canonical" href="<?= $h($url_site) ?>">

  <!-- Compartilhamento em redes sociais (Open Graph: Facebook, WhatsApp, LinkedIn, Telegram) -->
  <meta property="og:type" content="website">
  <meta property="og:locale" content="pt_BR">
  <meta property="og:site_name" content="Ministério de Mídia ADMoema">
  <meta property="og:url" content="<?= $h($url_site) ?>">
  <meta property="og:title" content="<?= $h($titulo_share) ?>">
  <meta property="og:description" content="<?= $h($descricao_share) ?>">
  <meta property="og:image" content="<?= $h($url_site) ?>img/og-image.jpg">
  <meta property="og:image:secure_url" content="<?= $h($url_site) ?>img/og-image.jpg">
  <meta property="og:image:type" content="image/jpeg">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:image:alt" content="Ministério de Mídia ADMoema — Proposta de Estruturação e Expansão">
  <!-- X / Twitter -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="<?= $h($titulo_share) ?>">
  <meta name="twitter:description" content="<?= $h($descricao_share) ?>">
  <meta name="twitter:image" content="<?= $h($url_site) ?>img/og-image.jpg">
  <meta name="twitter:image:alt" content="Ministério de Mídia ADMoema — Proposta de Estruturação e Expansão">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Fraunces:opsz,wght@9..144,500;9..144,600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?= $v('intro-splash.css') ?>">
  <link rel="stylesheet" href="<?= $v('styles.css') ?>">
  <link rel="icon" type="image/png" href="img/logo-belem.png">
  <link rel="apple-touch-icon" href="img/logo-belem.png">
</head>
<body>

  <!-- Abertura animada (logo-motion). Para regenerar com a logo oficial: veja README, seção "Animação da logo". -->
<div id="intro-splash" data-sempre="true" class="intro" data-recipe="draw" data-direction="left" data-duration="2.72" data-hold="0.5" style="--bg:#0b1f3a;--accent:#d4a72c;--fg:#ffffff;--k:0.85;--ls:30;--title-size:4.2;--stroke-width:2.5;--t-title:2s;--t-sub:2.4s;--t-line:2.6s;--font:'Manrope'" role="img" aria-label="Ministério de Mídia ADMoema — Assembleia de Deus · Ministério do Belém · Setor 124">
  <div class="intro__flare"></div>
  <div class="intro__stage">
    <div class="intro__logo intro__logo--a" style="--logo-mask:url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDgwIDEwMDAiPgogIAogIDxkZWZzPgogICAgPGxpbmVhckdyYWRpZW50IGlkPSJtaWRpYS1ncmFkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjIwMCIgeTE9IjE1MCIgeDI9IjkwMCIgeTI9Ijg2MCI+CiAgICAgIDxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iIzBkYjRjOCIvPgogICAgICA8c3RvcCBvZmZzZXQ9Ii40OCIgc3RvcC1jb2xvcj0iIzhhNjJhOCIvPgogICAgICA8c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNlNTFiODYiLz4KICAgIDwvbGluZWFyR3JhZGllbnQ+CiAgPC9kZWZzPgogIDxnIGZpbGw9Im5vbmUiIHN0cm9rZT0idXJsKCNtaWRpYS1ncmFkKSIgc3Ryb2tlLXdpZHRoPSI4OCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIj4KICAgIDxwYXRoIGQ9Ik0xODIgMTg2VjgxNiIvPgogICAgPHBhdGggZD0iTTM3MiAxODZWODE2Ii8+CiAgICA8cGF0aCBkPSJNMzcyIDIwNCA5NDUgNTAwIDM3MiA3OTZaIi8+CiAgPC9nPgogIDxnIGZpbGw9InVybCgjbWlkaWEtZ3JhZCkiPgogICAgPGNpcmNsZSBjeD0iMTgyIiBjeT0iMzc2IiByPSI5MiIvPgogICAgPGNpcmNsZSBjeD0iMzcyIiBjeT0iNjQwIiByPSI5MiIvPgogIDwvZz4KPC9zdmc+')"><svg class="logo-svg" focusable="false" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1000">
  
  <defs>
    <linearGradient id="midia-grad" gradientUnits="userSpaceOnUse" x1="200" y1="150" x2="900" y2="860">
      <stop offset="0" stop-color="#0db4c8"/>
      <stop offset=".48" stop-color="#8a62a8"/>
      <stop offset="1" stop-color="#e51b86"/>
    </linearGradient>
  </defs>
  <g fill="none" stroke="url(#midia-grad)" stroke-width="88" stroke-linecap="round" stroke-linejoin="round">
    <path d="M182 186V816" pathLength="1" class="draw draw--s" style="--i:0"/>
    <path d="M372 186V816" pathLength="1" class="draw draw--s" style="--i:1"/>
    <path d="M372 204 945 500 372 796Z" pathLength="1" class="draw draw--s" style="--i:2"/>
  </g>
  <g fill="url(#midia-grad)">
    <circle cx="182" cy="376" r="92" pathLength="1" class="draw draw--f" style="--i:3"/>
    <circle cx="372" cy="640" r="92" pathLength="1" class="draw draw--f" style="--i:4"/>
  </g>
</svg></div>
    <div class="intro__text"><h1 class="intro__title"><span class="w" style="--i:0">Ministério</span> <span class="w" style="--i:1">de</span> <span class="w" style="--i:2">Mídia</span> <span class="w" style="--i:3">ADMoema</span></h1><p class="intro__subtitle">Assembleia de Deus · Ministério do Belém · Setor 124</p></div>
  </div>
  <button type="button" class="intro__pular" aria-label="Pular abertura">Pular</button>
</div>


  <header class="topo" id="topo">
    <div class="container topo__inner">
      <a href="#inicio" class="marca" aria-label="Ministério de Mídia ADMoema">
        <span class="marca__logo marca__logo--ad" aria-hidden="true"><img src="img/logo-belem.png" alt="" width="44" height="44" onerror="this.parentNode.hidden=true"></span>
        <span class="marca__logo marca__logo--midia" aria-hidden="true"><img src="img/logo-midia.svg" alt="" width="32" height="30"></span>
        <span class="marca__texto"><strong>Mídia</strong> ADMoema</span>
      </a>
      <nav class="nav" aria-label="Seções da página">
        <a href="#prioridade">Ponto de partida</a>
        <a href="#proposito">Propósito</a>
        <a href="#frentes">Frentes</a>
        <a href="#tecnologia">Tecnologia</a>
        <a href="#organizacao">Organização</a>
        <a href="#visao">Visão</a>
      </nav>
      <a href="#formulario" class="btn btn--ouro btn--sm" data-cta="topo">Quero participar</a>
      <button class="menu-toggle" aria-label="Abrir menu" aria-expanded="false" aria-controls="menu-mobile">
        <span></span><span></span><span></span>
      </button>
    </div>
    <div class="menu-mobile" id="menu-mobile" hidden>
      <a href="#prioridade">Ponto de partida</a>
      <a href="#proposito">Propósito</a>
      <a href="#frentes">Frentes</a>
      <a href="#tecnologia">Tecnologia</a>
      <a href="#organizacao">Organização</a>
      <a href="#visao">Visão</a>
      <a href="#formulario" class="btn btn--ouro" data-cta="menu-mobile">Quero participar</a>
    </div>
  </header>

  <main>

    <!-- ===================== HERO ===================== -->
    <section class="hero" id="inicio" data-secao="inicio">
      <div class="hero__glow hero__glow--1" aria-hidden="true"></div>
      <div class="hero__glow hero__glow--2" aria-hidden="true"></div>
      <div class="container hero__inner">
        <img class="hero__brasao reveal" src="img/logo-belem.png" alt="Brasão da Assembleia de Deus – Ministério do Belém" width="96" height="112" onerror="this.hidden=true">
        <p class="hero__eyebrow reveal">Assembleia de Deus · Ministério do Belém · Setor 124 · Moema</p>
        <h1 class="hero__titulo reveal">Ministério de <span class="grad">Mídia</span> ADMoema</h1>
        <p class="hero__sub reveal">Proposta de Estruturação e Expansão</p>
        <blockquote class="hero__versiculo reveal">
          <p>“Assim nós, que somos muitos, somos um só corpo em Cristo, mas individualmente somos membros uns dos outros.”</p>
          <cite>Romanos 12:5</cite>
        </blockquote>
        <ul class="pilares reveal" aria-label="Pilares do ministério">
          <li>Servir</li><li>Comunicar</li><li>Capacitar</li><li>Evangelizar</li>
        </ul>
        <div class="hero__acoes reveal">
          <a href="#formulario" class="btn btn--ouro btn--lg" data-cta="hero">Onde posso contribuir?</a>
          <a href="#proposito" class="btn btn--fantasma btn--lg">Conhecer a proposta</a>
        </div>
      </div>
      <a href="#proposito" class="hero__scroll" aria-label="Rolar para o conteúdo"><span></span></a>
    </section>


    <!-- ===================== PONTO DE PARTIDA (pedido do Pr. Elias) ===================== -->
    <section class="secao secao--prioridade" id="prioridade" data-secao="prioridade">
      <div class="container">
        <div class="prioridade reveal">
          <div class="prioridade__cabecalho">
            <span class="prioridade__tag">Ponto-chave · Pedido do Pr. Elias</span>
            <h2>Por onde o Ministério de Multimídia começa: <span class="grad">edição de vídeo</span> das transmissões.</h2>
            <p class="lead">Na reunião do ministério, a pedido do <strong>Pr. Elias</strong>, ficou definido que o primeiro passo do projeto é
              transformar as transmissões (streams) já capturadas em arquivos de vídeo editados, prontos para publicar e preservar.</p>
          </div>

          <div class="prioridade__grade">
            <article class="videotipo">
              <div class="videotipo__icone" aria-hidden="true"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#e6bd4a" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 20V9a6 6 0 0 1 12 0v11"/><path d="M6 14h12M9 20h6"/><circle cx="12" cy="5" r="1"/></svg></div>
              <h3>Pregação</h3>
              <p>A mensagem de cada culto, recortada e identificada, para quem não pôde estar presente.</p>
            </article>
            <article class="videotipo">
              <div class="videotipo__icone" aria-hidden="true"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#e6bd4a" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="7" cy="17" r="3"/><circle cx="17" cy="15" r="3"/><path d="M10 17V6l10-2v11"/></svg></div>
              <h3>Louvor ministerial</h3>
              <p>Os momentos de louvor conduzidos pelo ministério de louvor da igreja.</p>
            </article>
            <article class="videotipo">
              <div class="videotipo__icone" aria-hidden="true"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#e6bd4a" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/></svg></div>
              <h3>Louvor individual</h3>
              <p>Participações individuais: cantores, instrumentistas e apresentações especiais.</p>
            </article>
            <article class="videotipo">
              <div class="videotipo__icone" aria-hidden="true"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#e6bd4a" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20a6 6 0 0 1 12 0M14 20a5 5 0 0 1 7-4.5"/></svg></div>
              <h3>Louvor dos ministérios</h3>
              <p>Coral, crianças, jovens, irmãs e qualquer ministério da ADMoema que ministre em louvor.</p>
            </article>
          </div>

          <div class="prioridade__chamada">
            <div>
              <p class="prioridade__pergunta"><strong>Precisamos saber quem são as pessoas do ministério</strong> que já sabem editar vídeo,
                que querem aprender ou que têm um projeto específico para esses vídeos.</p>
              <p class="prioridade__nota">Não é preciso ser profissional: quem sabe, ensina; quem começa, encontra espaço. O importante é se identificar agora.</p>
            </div>
            <a href="#formulario" class="btn btn--ouro btn--lg" data-cta="prioridade">Quero participar da edição de vídeo</a>
          </div>
        </div>
      </div>
    </section>

    <!-- ===================== PROPÓSITO ===================== -->
    <section class="secao" id="proposito" data-secao="proposito">
      <div class="container">
        <div class="grid-2">
          <div class="reveal">
            <p class="rotulo">Nosso propósito</p>
            <h2>A mídia é uma ferramenta para a Palavra alcançar mais pessoas.</h2>
            <p class="lead">A mídia não é apenas som, projeção, fotos ou redes sociais. É o meio pelo qual a mensagem chega a quem está no templo e a quem está longe.</p>
            <p class="destaque-frase">“Onde posso contribuir melhor para a obra do Senhor?”</p>
          </div>
          <div class="reveal">
            <p class="rotulo rotulo--pequeno">Para que a Palavra de Deus seja</p>
            <ul class="lista-palavra">
              <li><span class="num">01</span><div><strong>Ouvida</strong><small>com clareza, em cada culto</small></div></li>
              <li><span class="num">02</span><div><strong>Compreendida</strong><small>com apoio visual e organização</small></div></li>
              <li><span class="num">03</span><div><strong>Registrada</strong><small>em áudio, vídeo e fotografia</small></div></li>
              <li><span class="num">04</span><div><strong>Preservada</strong><small>como história da igreja</small></div></li>
              <li><span class="num">05</span><div><strong>Levada a quem está longe</strong><small>pela transmissão e pelas redes</small></div></li>
            </ul>
          </div>
        </div>

        <div class="servimos reveal">
          <p class="rotulo rotulo--pequeno">A quem servimos</p>
          <ul class="chips">
            <li>Pastores e liderança</li>
            <li>Ministérios e departamentos</li>
            <li>Membros e visitantes</li>
            <li>Missionários</li>
            <li>Coral, músicos e professores</li>
            <li>Secretaria, eventos e evangelismo</li>
          </ul>
        </div>
      </div>
    </section>

    <!-- ===================== POR QUE IMPORTA ===================== -->
    <section class="secao secao--escura" id="importancia" data-secao="importancia">
      <div class="container">
        <div class="cabecalho-secao reveal">
          <p class="rotulo">Por que o trabalho de mídia importa</p>
          <h2>Ninguém é apenas um “operador de equipamento”.</h2>
          <p class="lead">Cada integrante participa de algo maior.</p>
        </div>
        <div class="cards cards--3">
          <article class="card card--vidro reveal">
            <div class="card__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 7h3l2-2h6l2 2h3v12H4z"/><circle cx="12" cy="13" r="3.5"/></svg></div>
            <h3>Atrás de uma câmera</h3>
            <p>alguém leva a mensagem para quem está em casa.</p>
          </article>
          <article class="card card--vidro reveal">
            <div class="card__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 10v4h4l5 4V6l-5 4z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/></svg></div>
            <h3>Atrás da mesa de som</h3>
            <p>alguém faz a Palavra ser ouvida com clareza.</p>
          </article>
          <article class="card card--vidro reveal">
            <div class="card__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg></div>
            <h3>Atrás da projeção</h3>
            <p>alguém ajuda a igreja a louvar.</p>
          </article>
          <article class="card card--vidro reveal">
            <div class="card__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 16 5-5 4 4 3-3 6 6"/><circle cx="16" cy="9" r="1.5"/></svg></div>
            <h3>Atrás de uma fotografia</h3>
            <p>alguém preserva a história da igreja.</p>
          </article>
          <article class="card card--vidro reveal">
            <div class="card__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="6" rx="1.5"/><rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M7 7h.01M7 17h.01"/></svg></div>
            <h3>Atrás de um sistema</h3>
            <p>alguém facilita o trabalho de outro ministério.</p>
          </article>
          <article class="card card--vidro reveal">
            <div class="card__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M21 12 3 4l3 8-3 8z"/><path d="M6 12h15"/></svg></div>
            <h3>Atrás de uma publicação</h3>
            <p>alguém pode ser alcançado pelo Evangelho.</p>
          </article>
        </div>
      </div>
    </section>

    <!-- ===================== NOVE FRENTES ===================== -->
    <section class="secao" id="frentes" data-secao="frentes">
      <div class="container">
        <div class="cabecalho-secao reveal">
          <p class="rotulo">Nove frentes de trabalho</p>
          <h2>Frentes, não cargos.</h2>
          <p class="lead">Cada irmão escolhe onde já sabe, onde quer aprender e onde pode ajudar.</p>
        </div>
        <div class="frentes">
          <article class="frente reveal" data-frente="Áudio e sonorização">
            <span class="frente__n">01</span>
            <div class="frente__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 3v18M7 8v8M17 8v8M3 11v2M21 11v2"/></svg></div>
            <h3>Áudio e sonorização</h3>
          </article>
          <article class="frente reveal" data-frente="Projeção">
            <span class="frente__n">02</span>
            <div class="frente__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg></div>
            <h3>Projeção</h3>
          </article>
          <article class="frente reveal" data-frente="Transmissão ao vivo">
            <span class="frente__n">03</span>
            <div class="frente__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="2.5"/><path d="M7.5 7.5a6.5 6.5 0 0 0 0 9M16.5 7.5a6.5 6.5 0 0 1 0 9M4.5 4.5a10.5 10.5 0 0 0 0 15M19.5 4.5a10.5 10.5 0 0 1 0 15"/></svg></div>
            <h3>Transmissão ao vivo</h3>
          </article>
          <article class="frente reveal" data-frente="Câmeras e direção">
            <span class="frente__n">04</span>
            <div class="frente__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="7" width="13" height="10" rx="2"/><path d="m16 10 5-2v8l-5-2z"/></svg></div>
            <h3>Câmeras e direção</h3>
          </article>
          <article class="frente reveal" data-frente="Fotografia">
            <span class="frente__n">05</span>
            <div class="frente__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 7h3l2-2h6l2 2h3v12H4z"/><circle cx="12" cy="13" r="3.5"/></svg></div>
            <h3>Fotografia</h3>
          </article>
          <article class="frente reveal" data-frente="Produção de vídeos">
            <span class="frente__n">06</span>
            <div class="frente__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18M8 5v4M16 5v4M10 12l4 2.5-4 2.5z"/></svg></div>
            <h3>Produção de vídeos</h3>
          </article>
          <article class="frente reveal" data-frente="Design e identidade visual">
            <span class="frente__n">07</span>
            <div class="frente__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 2-2v-1c0-1 .5-2 2-2h1a4 4 0 0 0 4-4c0-5-4-9-9-9z"/><circle cx="7.5" cy="11.5" r="1"/><circle cx="10.5" cy="7.5" r="1"/><circle cx="15.5" cy="7.5" r="1"/></svg></div>
            <h3>Design e identidade visual</h3>
          </article>
          <article class="frente reveal" data-frente="Redes sociais">
            <span class="frente__n">08</span>
            <div class="frente__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="m8.2 10.8 7.6-4.6M8.2 13.2l7.6 4.6"/></svg></div>
            <h3>Redes sociais</h3>
          </article>
          <article class="frente reveal" data-frente="Sistemas e tecnologia">
            <span class="frente__n">09</span>
            <div class="frente__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/></svg></div>
            <h3>Sistemas e tecnologia</h3>
          </article>
        </div>
        <div class="principio reveal">
          <div class="principio__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="7" r="3"/><circle cx="5" cy="17" r="2.5"/><circle cx="19" cy="17" r="2.5"/><path d="M12 10v3M12 13l-5 2M12 13l5 2"/></svg></div>
          <div>
            <p class="rotulo rotulo--pequeno">Princípio</p>
            <p><strong>Nenhuma função deve depender de uma única pessoa</strong> — sempre <em>titular</em>, <em>apoio</em> e <em>aprendiz</em>.</p>
            <p class="principio__nota">Não é hierarquia, é continuidade.</p>
          </div>
        </div>
      </div>
    </section>

    <!-- ===================== TECNOLOGIA ===================== -->
    <section class="secao secao--escura" id="tecnologia" data-secao="tecnologia">
      <div class="container">
        <div class="cabecalho-secao reveal">
          <p class="rotulo">Tecnologia a serviço da igreja</p>
          <h2>Não apenas consumir tecnologia — <span class="grad">criar</span> tecnologia para servir a ADMoema.</h2>
        </div>

        <div class="grid-2 grid-2--topo">
          <div class="reveal">
            <h3 class="subtitulo"><span class="ponto ponto--ok"></span>O que já construímos</h3>
            <ul class="projetos">
              <li>
                <strong>Sistema Cantata 2025</strong>
                <span>Apoio à organização da Cantata.</span>
              </li>
              <li>
                <strong>Sistema do Coral</strong>
                <span>Ensaios, afinação e apoio ao maestro.</span>
              </li>
              <li>
                <strong>Biblioteca Digital</strong>
                <span>Em fase de testes.</span>
                <em class="tag">beta</em>
              </li>
            </ul>
          </div>
          <div class="reveal">
            <h3 class="subtitulo"><span class="ponto ponto--futuro"></span>Onde podemos chegar</h3>
            <ul class="lista-check">
              <li>Recepção de visitantes</li>
              <li>Pedidos de oração</li>
              <li>Hinário Digital ADMoema</li>
              <li>Controle de eventos</li>
              <li>Automação de comunicação e newsletter</li>
              <li>Escala inteligente da equipe</li>
              <li>Apoio missionário <small>(após autorização pastoral)</small></li>
            </ul>
          </div>
        </div>

        <div class="ecossistema reveal">
          <div class="ecossistema__bloco">
            <span class="ecossistema__tag">Central Digital ADMoema</span>
            <span class="ecossistema__mais" aria-hidden="true">+</span>
            <span class="ecossistema__tag">ADMoema Criativo</span>
          </div>
          <p>Um único ecossistema e um gerador de banners no padrão visual da igreja.</p>
        </div>
      </div>
    </section>

    <!-- ===================== ORGANIZAÇÃO ===================== -->
    <section class="secao" id="organizacao" data-secao="organizacao">
      <div class="container">
        <div class="cabecalho-secao reveal">
          <p class="rotulo">Como vamos nos organizar</p>
          <h2>Não implementar tudo ao mesmo tempo.</h2>
          <p class="lead">Poucas prioridades, bem feitas.</p>
        </div>

        <ol class="timeline">
          <li class="timeline__item reveal">
            <span class="timeline__periodo">0 – 30 dias</span>
            <h3>Organização interna</h3>
            <p>Levantamento de habilidades, frentes, central técnica, documentação e checklists.</p>
          </li>
          <li class="timeline__item reveal">
            <span class="timeline__periodo">30 – 60 dias</span>
            <h3>Comunicação</h3>
            <p>Identidade visual, templates, calendário de redes e organização de fotos e vídeos.</p>
          </li>
          <li class="timeline__item reveal">
            <span class="timeline__periodo">60 – 90 dias</span>
            <h3>Tecnologia</h3>
            <p>Um ou dois projetos prioritários — não cinco ou dez.</p>
          </li>
        </ol>

        <div class="cards cards--4">
          <article class="card reveal">
            <div class="card__icone card__icone--claro" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 19V6a2 2 0 0 1 2-2h6v15H6a2 2 0 0 0-2 2zM12 4h6a2 2 0 0 1 2 2v13a2 2 0 0 0-2-2h-6"/></svg></div>
            <h3>Aprenda e ensine</h3>
            <p>Quem sabe, ensina; quem começa, encontra espaço.</p>
          </article>
          <article class="card reveal">
            <div class="card__icone card__icone--claro" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="11" rx="2"/><path d="M7 20h10M9 16v4M15 16v4M7 9h4M7 12h6"/></svg></div>
            <h3>Central técnica</h3>
            <p>Estação de áudio + estação de direção de transmissão, e um apoio móvel.</p>
          </article>
          <article class="card reveal">
            <div class="card__icone card__icone--claro" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M9 4h6l1 2h3v14H5V6h3z"/><path d="m8.5 13 2.5 2.5 4.5-5"/></svg></div>
            <h3>Manual e checklists</h3>
            <p>Abertura e encerramento documentados; menos erros, mais treinamento.</p>
          </article>
          <article class="card reveal">
            <div class="card__icone card__icone--claro" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 21s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.6-7 10-7 10z"/></svg></div>
            <h3>Cultura de ministério</h3>
            <p>Sem culpados: “como evitamos que aconteça de novo?”</p>
          </article>
        </div>
      </div>
    </section>

    <!-- ===================== VISÃO + FORMULÁRIO ===================== -->
    <section class="secao secao--visao" id="visao" data-secao="visao">
      <div class="container">
        <div class="visao reveal">
          <p class="rotulo">Nossa visão</p>
          <h2 class="visao__formula">
            <span>Tecnologia</span><i>+</i><span>Comunicação</span><i>+</i><span>Criatividade</span><i>+</i><span>Organização</span><i>+</i><span>Conhecimento</span>
          </h2>
          <p class="lead">a serviço da igreja e, acima de tudo, da obra do Senhor.</p>
        </div>
      </div>
    </section>

    <section class="secao secao--form" id="formulario" data-secao="formulario">
      <div class="container container--estreito">
        <div class="cabecalho-secao reveal">
          <p class="rotulo">Três perguntas para cada integrante</p>
          <h2>Onde você pode contribuir?</h2>
          <p class="lead">Responda com sinceridade. Não existe resposta pequena: cada habilidade e cada vontade de aprender encontram lugar em uma das frentes. Se você edita vídeo, quer aprender ou tem um projeto para os vídeos das transmissões, marque logo abaixo.</p>
        </div>

        <form class="form reveal" id="form-perguntas" novalidate>
          <div class="form__linha form__linha--2">
            <div class="campo">
              <label for="nome">Seu nome <span class="obrig">*</span></label>
              <input type="text" id="nome" name="nome" autocomplete="name" maxlength="120" required placeholder="Como podemos te chamar?">
              <small class="erro" data-erro-para="nome"></small>
            </div>
            <div class="campo">
              <label for="contato">WhatsApp ou e-mail <span class="opcional">(opcional)</span></label>
              <input type="text" id="contato" name="contato" autocomplete="tel" maxlength="160" placeholder="Para conversarmos com você">
            </div>
          </div>

          <fieldset class="campo campo--edicao">
            <legend>Edição de vídeo das transmissões <span class="obrig">*</span> <span class="opcional">(ponto de partida do projeto, a pedido do Pr. Elias)</span></legend>
            <div class="opcoes-radio" id="edicao-video">
              <label><input type="radio" name="edicaoVideo" value="ja_edito"><span class="caixa caixa--radio"></span><span>Já sei editar vídeos</span></label>
              <label><input type="radio" name="edicaoVideo" value="quero_aprender"><span class="caixa caixa--radio"></span><span>Quero aprender a editar</span></label>
              <label><input type="radio" name="edicaoVideo" value="tenho_projeto"><span class="caixa caixa--radio"></span><span>Tenho um projeto específico</span></label>
              <label><input type="radio" name="edicaoVideo" value="ainda_nao"><span class="caixa caixa--radio"></span><span>Ainda não, mas quero ajudar em outra frente</span></label>
            </div>
            <small class="erro" data-erro-para="edicaoVideo"></small>
          </fieldset>

          <fieldset class="campo campo--frentes">
            <legend>Frentes com que você se identifica <span class="opcional">(marque quantas quiser)</span></legend>
            <div class="frentes-check" id="frentes-check">
              <!-- preenchido via JS a partir de /api/frentes -->
            </div>
          </fieldset>

          <div class="pergunta">
            <span class="pergunta__n">1</span>
            <div class="campo">
              <label for="sabeFazer">O que você já sabe fazer e poderia compartilhar conosco? <span class="obrig">*</span></label>
              <textarea id="sabeFazer" name="sabeFazer" rows="4" maxlength="2000" required placeholder="Ex.: mexo com edição de vídeo, sei operar mesa de som, tiro fotos, programo..."></textarea>
              <small class="erro" data-erro-para="sabeFazer"></small>
            </div>
          </div>

          <div class="pergunta">
            <span class="pergunta__n">2</span>
            <div class="campo">
              <label for="querAprender">O que você gostaria de aprender dentro da mídia? <span class="obrig">*</span></label>
              <textarea id="querAprender" name="querAprender" rows="4" maxlength="2000" required placeholder="Ex.: transmissão ao vivo, design, direção de câmeras..."></textarea>
              <small class="erro" data-erro-para="querAprender"></small>
            </div>
          </div>

          <div class="pergunta">
            <span class="pergunta__n">3</span>
            <div class="campo">
              <label for="projetoAjudar">Qual projeto gostaria de ajudar a construir? <span class="obrig">*</span></label>
              <textarea id="projetoAjudar" name="projetoAjudar" rows="4" maxlength="2000" required placeholder="Ex.: editar as pregações e louvores das transmissões, Hinário Digital, pedidos de oração, escala da equipe..."></textarea>
              <small class="erro" data-erro-para="projetoAjudar"></small>
            </div>
          </div>

          <div class="form__rodape">
            <p class="form__aviso">Suas respostas são registradas com segurança e usadas apenas pela liderança do ministério para organizar as frentes e os projetos.</p>
            <button type="submit" class="btn btn--ouro btn--lg" id="btn-enviar">
              <span class="btn__texto">Enviar minhas respostas</span>
              <span class="btn__carregando" aria-hidden="true"></span>
            </button>
          </div>
          <p class="form__status" id="form-status" role="status" aria-live="polite"></p>
        </form>

        <div class="sucesso" id="sucesso" hidden>
          <div class="sucesso__icone" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></div>
          <h3 id="sucesso-titulo">Resposta registrada!</h3>
          <p>Obrigado por se colocar à disposição. Em breve a liderança do ministério entrará em contato para conversar sobre as frentes e os projetos.</p>
          <p class="sucesso__versiculo">“Mas faça-se tudo decentemente e com ordem.” <cite>1 Coríntios 14:40</cite></p>
          <button type="button" class="btn btn--fantasma" id="btn-nova">Enviar outra resposta</button>
        </div>
      </div>
    </section>

  </main>

  <footer class="rodape">
    <div class="container rodape__inner">
      <div class="rodape__logos"><img src="img/logo-belem.png" alt="Assembleia de Deus – Ministério do Belém" width="72" height="84" onerror="this.hidden=true"><img src="img/logo-midia.svg" alt="Ministério de Mídia ADMoema" width="60" height="56"></div>
      <blockquote class="rodape__versiculo">
        <p>“Mas faça-se tudo decentemente e com ordem.”</p>
        <cite>1 Coríntios 14:40</cite>
      </blockquote>
      <ul class="pilares pilares--rodape" aria-label="Pilares do ministério">
        <li>Servir</li><li>Comunicar</li><li>Capacitar</li><li>Evangelizar</li>
      </ul>
      <p class="rodape__copy">Ministério de Mídia ADMoema · Assembleia de Deus – Ministério do Belém · Setor 124 · Moema</p>
    </div>
  </footer>

  <script src="<?= $v('intro-splash.js') ?>" defer></script>
  <script src="<?= $v('app.js') ?>" defer></script>
</body>
</html>
