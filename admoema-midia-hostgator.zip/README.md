# Ministério de Mídia ADMoema

Landing page com a proposta de estruturação e expansão do Ministério de Mídia da
Assembleia de Deus – Ministério do Belém (Setor 124 · Moema), com o formulário das
**três perguntas para cada integrante** e banco de dados que registra as respostas e as
ações dos visitantes.

Feito para hospedagem compartilhada (HostGator): **PHP + SQLite**, sem instalação, sem
terminal. Basta subir os arquivos.

## Como publicar na HostGator (sem terminal)

1. **Baixe o pacote** `admoema-midia-hostgator.zip` (está na raiz deste repositório).
2. Entre no **cPanel → Arquivos → Gerenciador de Arquivos**.
3. Abra a pasta do seu site (normalmente `public_html`). Se quiser a página em um
   endereço como `seusite.com.br/midia`, crie a pasta `midia` e entre nela.
   Se quiser na raiz do domínio, fique em `public_html` mesmo.
4. Clique em **Upload** e envie o arquivo `.zip`.
5. Volte ao Gerenciador, clique com o botão direito no `.zip` → **Extract** (extrair) na
   pasta atual. Depois apague o `.zip`.
6. Confira que `index.html`, `admin.html`, a pasta `api` e a pasta `dados` ficaram
   **diretamente** na pasta escolhida (e não dentro de uma subpasta).
7. Abra o endereço no navegador. Na primeira visita o banco de dados é criado
   automaticamente em `dados/admoema-midia.sqlite`.

Pronto. A página já está no ar e o formulário já grava no banco.

### Senha do painel

Não é preciso gerar nada. A senha do painel é um texto que fica no arquivo
`api/config.php`, na linha:

```php
const SENHA_ADMIN = 'Midia@ADMoema2026';
```

Ela já vem preenchida com esse valor. **Recomendado:** troque por uma senha sua.
No Gerenciador de Arquivos, clique com o botão direito em `api/config.php` → **Edit**,
altere o texto entre aspas e salve.

### Painel administrativo

Acesse `seusite.com.br/midia/admin.html` (ou `/admin.html` na raiz) e informe a senha.
O painel mostra:

- totais de respostas, visitantes únicos, visitas, formulários iniciados e cliques nas chamadas para ação;
- as frentes mais marcadas;
- a tabela com as três respostas de cada integrante e o botão **Baixar respostas (CSV)** (abre no Excel);
- o registro completo de ações.

## Requisitos na hospedagem

- PHP 7.4 ou superior (a HostGator já oferece 8.x) com a extensão `pdo_sqlite` (padrão).
- A pasta `dados` precisa ter permissão de escrita (o padrão 755 do cPanel funciona,
  porque o PHP roda com o seu usuário). Se aparecer "Erro interno", ajuste para 755 ou 775.

### Opcional: usar MySQL em vez de SQLite

Se preferir um banco MySQL, crie o banco e o usuário em **cPanel → Bancos de Dados
MySQL**, depois em `api/config.php` altere `BANCO_TIPO` para `'mysql'` e preencha
`MYSQL_HOST`, `MYSQL_BANCO`, `MYSQL_USUARIO` e `MYSQL_SENHA`. As tabelas são criadas
automaticamente.

## Conteúdo da página

1. **Início** — título, Romanos 12:5 e os pilares Servir · Comunicar · Capacitar · Evangelizar
2. **Nosso propósito** — para que a Palavra seja ouvida, compreendida, registrada, preservada e levada a quem está longe; a quem servimos
3. **Por que o trabalho de mídia importa**
4. **Nove frentes de trabalho** — frentes, não cargos; titular, apoio e aprendiz
5. **Tecnologia a serviço da igreja** — o que já construímos, onde podemos chegar, Central Digital ADMoema + ADMoema Criativo
6. **Como vamos nos organizar** — 0–30, 30–60 e 60–90 dias; cultura de ministério
7. **Nossa visão + formulário** com as três perguntas:
   1. O que você já sabe fazer e poderia compartilhar conosco?
   2. O que você gostaria de aprender dentro da mídia?
   3. Qual projeto gostaria de ajudar a construir?

## Banco de dados

Criado automaticamente pelo `api/db.php`.

**Tabela `respostas`** — `id`, `nome`, `contato` (opcional), `frentes` (JSON com as
frentes marcadas), `sabe_fazer` (pergunta 1), `quer_aprender` (pergunta 2),
`projeto_ajudar` (pergunta 3), `criado_em`.

**Tabela `acoes`** (registro de ações) — `id`, `tipo` (`pagina_visitada`, `secao_vista`,
`cta_clicado`, `formulario_iniciado`, `formulario_enviado`, `formulario_erro`,
`admin_acesso`), `detalhe` (JSON), `resposta_id`, `sessao` (identificador anônimo do
navegador), `ip`, `user_agent`, `criado_em`.

As datas usam o fuso `America/Sao_Paulo` (ajustável em `api/config.php`).

## API

| Rota | Descrição |
| --- | --- |
| `GET api/frentes.php` | lista das nove frentes |
| `POST api/acoes.php` | registra uma ação do navegador |
| `POST api/respostas.php` | envia o formulário |
| `GET api/admin.php?recurso=respostas` | lista respostas (cabeçalho `X-Senha-Admin`) |
| `GET api/admin.php?recurso=acoes` | lista ações (cabeçalho `X-Senha-Admin`) |
| `GET api/admin.php?recurso=resumo` | totais e frentes mais marcadas |
| `GET api/admin.php?recurso=csv&senha=...` | download das respostas em CSV |

## Estrutura

```
index.html        landing page
styles.css        estilos
app.js            interações, formulário e registro de ações
admin.html        painel administrativo
api/config.php    senha do painel e banco (único arquivo a ajustar)
api/db.php        conexão e criação das tabelas
api/*.php         rotas da API
dados/            banco SQLite (protegido por .htaccess)
.htaccess         configurações do Apache
```

## Testar no computador (opcional)

Com PHP instalado: `php -S localhost:8000` na pasta do projeto e abra
<http://localhost:8000>.
